cd /cygdrive/c/workspace/AndEnginePhysicsBox2DExtension/
/cygdrive/c/workspace/sdk/android-ndk-r6/ndk-build